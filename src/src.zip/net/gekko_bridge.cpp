/**
 * Alice Senki 2 - Gekko Bridge Implementation
 *
 * Central integration bridge between online_wiring (the lifecycle glue)
 * and the subsystems that participate in online gameplay:
 *
 *   - Rollback session (rollback_session)
 *   - Player side mapping (player_side_mapping)
 *   - Delay policy (delay_policy)
 *
 * online_wiring calls THROUGH this bridge for session start/stop, input
 * submission, and per-frame updates. This bridge owns the session lifecycle
 * contract and provides verification logging.
 *
 * GekkoNet library is still smoke-tested at init for link verification.
 */

#include "net/gekko_bridge.h"
#include "net/player_side_mapping.h"
#include "net/delay_policy.h"
#include "rollback/rollback_session.h"
#include "rollback/resimulation.h"
#include "rollback/netplay_log.h"
#include "ui/log_window.h"

#include <string.h>
#include <stdio.h>

// GekkoNet library header — used only for smoke test
#ifndef GEKKONET_STATIC
#define GEKKONET_STATIC
#endif

// Forward-declare GekkoNet types to avoid hard dependency on header
// when library is not available. The actual library is optional.
struct GekkoSession;
enum GekkoSessionType : int;

// Weak references to GekkoNet symbols — resolved at link time if library
// is present, otherwise we detect the failure at runtime.
extern "C" {
    __declspec(selectany) bool (*gekko_create_ptr)(GekkoSession**, int) = nullptr;
    __declspec(selectany) bool (*gekko_destroy_ptr)(GekkoSession**) = nullptr;
}

namespace Net {

// ============================================================================
// Internal State
// ============================================================================

static bool s_initialized       = false;
static bool s_libraryAvailable  = false;
static bool s_sessionActive     = false;
static char s_status[128]       = "GekkoBridge not initialized.";
static char s_pinnedVersion[48] = "v20260316133147-7f1f19e";

// Per-session counters for verification logging
static int  s_framesUpdated         = 0;
static int  s_remoteInputsSubmitted = 0;
static int  s_delayPolicyConsumed   = 0;
static int  s_lastConsumedDelay     = -1;

static void SetStatus(const char* fmt, ...) {
    va_list args;
    va_start(args, fmt);
    vsnprintf_s(s_status, sizeof(s_status), _TRUNCATE, fmt, args);
    va_end(args);
}

// ============================================================================
// GekkoNet Library Smoke Test
// ============================================================================

/// Attempt to create and immediately destroy a GekkoNet stress session.
/// This validates that the library is correctly linked without keeping
/// any resources allocated.
static bool SmokeTestLibrary() {
#ifdef GEKKONET_AVAILABLE
    GekkoSession* session = nullptr;
    if (!gekko_create(&session, GekkoStressSession)) {
        LOG_WARN("[GekkoBridge] gekko_create smoke test failed");
        return false;
    }
    if (!gekko_destroy(&session)) {
        LOG_WARN("[GekkoBridge] gekko_destroy smoke test failed");
        return false;
    }
    return true;
#else
    // GekkoNet library not linked into this build
    return false;
#endif
}

// ============================================================================
// Lifecycle
// ============================================================================

bool GekkoBridge_Init() {
    if (s_initialized) return s_libraryAvailable;

    s_initialized = true;
    s_sessionActive = false;

    // Attempt library smoke test
    s_libraryAvailable = SmokeTestLibrary();

    if (s_libraryAvailable) {
        SetStatus("GekkoNet library linked and smoke-tested (%s).", s_pinnedVersion);
        LOG_INFO("[GekkoBridge] GekkoNet library available: %s", s_pinnedVersion);
    } else {
        SetStatus("GekkoNet library not available. Using mod-owned rollback.");
        LOG_INFO("[GekkoBridge] GekkoNet library not available — using mod-owned rollback session");
    }

    return s_libraryAvailable;
}

void GekkoBridge_Shutdown() {
    if (!s_initialized) return;

    if (s_sessionActive) {
        GekkoBridge_EndSession();
    }

    s_initialized = false;
    s_libraryAvailable = false;
    SetStatus("GekkoBridge shut down.");
    LOG_INFO("[GekkoBridge] Shut down");
}

bool GekkoBridge_IsLibraryAvailable() {
    return s_libraryAvailable;
}

const char* GekkoBridge_GetPinnedVersion() {
    return s_pinnedVersion;
}

// ============================================================================
// Bridge Status
// ============================================================================

void GekkoBridge_GetSnapshot(GekkoBridgeSnapshot* out) {
    if (!out) return;
    memset(out, 0, sizeof(*out));

    out->initialized = s_initialized;
    out->library_available = s_libraryAvailable;
    out->session_active = s_sessionActive;
    out->local_game_slot = PlayerMapping_GetLocalGameSlot();
    out->remote_game_slot = PlayerMapping_GetRemoteGameSlot();
    out->active_delay = DelayPolicy_GetActiveDelay();
    out->rollback_budget = DelayPolicy_GetAgreedRollbackBudget();
    out->current_frame = Rollback::RollbackSession_GetCurrentFrame();

    strncpy_s(out->status, sizeof(out->status), s_status, _TRUNCATE);
    strncpy_s(out->pinned_version, sizeof(out->pinned_version),
              s_pinnedVersion, _TRUNCATE);
}

// ============================================================================
// Gameplay Session Control
// ============================================================================

bool GekkoBridge_StartSession(const Rollback::RollbackSessionConfig& config) {
    if (s_sessionActive) {
        LOG_WARN("[GekkoBridge] Session already active — ending previous");
        GekkoBridge_EndSession();
    }

    // Reset per-session counters
    s_framesUpdated = 0;
    s_remoteInputsSubmitted = 0;
    s_delayPolicyConsumed = 0;
    s_lastConsumedDelay = -1;

    // Set player mapping from the config
    PlayerMapping_SetAssignment(config.local_player);

    // Verify player mapping was applied correctly
    int verifyLocal = PlayerMapping_GetLocalGameSlot();
    int verifyRemote = PlayerMapping_GetRemoteGameSlot();
    if (verifyLocal != config.local_player || verifyRemote != config.remote_player) {
        LOG_ERROR("[GekkoBridge] Player mapping mismatch! expected local=P%d remote=P%d, got local=P%d remote=P%d",
            config.local_player + 1, config.remote_player + 1,
            verifyLocal + 1, verifyRemote + 1);
        Rollback::NetplayLog_Write("BRIDGE", -1,
            "ERROR: Player mapping mismatch after SetAssignment");
        PlayerMapping_Clear();
        SetStatus("Player mapping verification failed.");
        return false;
    }

    // Start the mod-owned rollback session
    bool ok = Rollback::RollbackSession_Begin(config);
    if (!ok) {
        LOG_ERROR("[GekkoBridge] RollbackSession_Begin failed");
        Rollback::NetplayLog_Write("BRIDGE", -1,
            "ERROR: RollbackSession_Begin FAILED");
        PlayerMapping_Clear();
        SetStatus("Failed to start gameplay session.");
        return false;
    }

    s_sessionActive = true;
    SetStatus("Gameplay session active (mod-owned rollback).");

    LOG_INFO("[GekkoBridge] Session started: local=P%d remote=P%d delay=%d budget=%d",
        config.local_player + 1, config.remote_player + 1,
        config.initial_delay, config.rollback_budget);
    Rollback::NetplayLog_Write("BRIDGE", config.start_frame,
        "Session started via GekkoBridge: local=P%d remote=P%d delay=%d budget=%d baseline=0x%08X",
        config.local_player + 1, config.remote_player + 1,
        config.initial_delay, config.rollback_budget, config.baseline_checksum);

    return true;
}

void GekkoBridge_EndSession() {
    if (!s_sessionActive) return;

    // Log session summary before teardown
    int32_t frame = Rollback::RollbackSession_GetCurrentFrame();
    Rollback::NetplayLog_Write("BRIDGE", frame,
        "Session ending via GekkoBridge: frames_updated=%d remote_inputs=%d delay_consumed=%d",
        s_framesUpdated, s_remoteInputsSubmitted, s_delayPolicyConsumed);

    Rollback::RollbackSession_End();
    PlayerMapping_Clear();

    s_sessionActive = false;
    SetStatus("Gameplay session ended.");
    LOG_INFO("[GekkoBridge] Session ended (frames=%d inputs=%d)",
        s_framesUpdated, s_remoteInputsSubmitted);
}

bool GekkoBridge_IsSessionActive() {
    return s_sessionActive;
}

// ============================================================================
// Per-Frame
// ============================================================================

void GekkoBridge_FrameUpdate() {
    if (!s_sessionActive) return;

    s_framesUpdated++;

    // Consume delay policy — complete the Requested→Applied cycle
    GekkoBridge_ConsumeDelayPolicy();
}

void GekkoBridge_ConsumeDelayPolicy() {
    if (!s_sessionActive) return;

    if (!DelayPolicy_IsGekkoSynced()) {
        int activeDelay = Rollback::RollbackSession_GetActiveDelay();
        DelayPolicy_OnGekkoApplied(activeDelay);
        s_delayPolicyConsumed++;

        if (activeDelay != s_lastConsumedDelay) {
            Rollback::NetplayLog_Write("BRIDGE",
                Rollback::RollbackSession_GetCurrentFrame(),
                "Delay policy consumed: %d -> %d",
                s_lastConsumedDelay, activeDelay);
            s_lastConsumedDelay = activeDelay;
        }
    }
}

// ============================================================================
// Input Routing
// ============================================================================

uint16_t GekkoBridge_ReadLocalInput() {
    return PlayerMapping_ReadLocalInput();
}

void GekkoBridge_SubmitRemoteInput(int32_t frame, uint16_t input) {
    Rollback::RollbackSession_SubmitRemoteInput(frame, input);
    s_remoteInputsSubmitted++;
}

} // namespace Net
